#pragma once
#include <vector>
#include "Warrior.h"

class Medic : public Soldier {
private:
	CommandType currentCommand;
public:
	Medic(double start_x, double start_y, int team_id);

	void Show();
};