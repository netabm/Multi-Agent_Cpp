#pragma once
#include <vector>
#include "Warrior.h"

enum SupportState {
	IDLE,
	MOVING_TO_WAREHOUSE,
	MOVING_TO_WARRIOR
};

class SupplySoldier : public Soldier {
private:
	SupportState current_support_state = IDLE;
	Warrior* target_warrior = nullptr; // Warrior needing ammo
public:
	SupplySoldier(double start_x, double start_y, int team_id);

	void Show();

	// Assigns the task (called ONCE by Commander)
	void AssignSupplyTask(Warrior* warrior_to_supply);

	// Main AI update function
	void Update(int map[MSZ][MSZ], double securityMap[MSZ][MSZ]);

	SupportState getSupplyState() const { return current_support_state; };
	//void GiveAmmo(Warrior* warrior, int map[MSZ][MSZ], double securityMap[MSZ][MSZ]);
};