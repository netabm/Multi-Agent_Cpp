#include "SupportSoldier.h"

void SupportSoldier::AssignSupportTask(Warrior* warrior_to_support) {
    if (!IsAlive() || current_state != IDLE) return;

    target_warrior = warrior_to_support;
    current_state = MOVING_TO_WAREHOUSE;
    path.clear();
    isMoving = false;
}

void SupportSoldier::Update(int map[MSZ][MSZ], double securityMap[MSZ][MSZ]) {
    if (!IsAlive()) {
        current_state = IDLE;
        target_warrior = nullptr;
        isMoving = false;
        path.clear();
        return;
    }

    if (target_warrior && !target_warrior->IsAlive()) {
        current_state = IDLE;
        target_warrior = nullptr;
        isMoving = false;
        path.clear();
        return;
    }

    if (current_state == IDLE) return;

    Point2D currentPos = getPosition();
    Point2D warehouse = GetWarehousePosition();
    Point2D warriorPos = target_warrior ? target_warrior->getPosition() : Point2D{ -1,-1 };

    switch (current_state) {
    case MOVING_TO_WAREHOUSE:
        if (!isMoving) {
            SetTarget(warehouse.x, warehouse.y, map, securityMap);
            if (!isMoving) {
                current_state = IDLE;
                target_warrior = nullptr;
            }
        }
        else if (isNear(warehouse)) {
            current_state = MOVING_TO_WARRIOR;
        }
        break;

    case MOVING_TO_WARRIOR:
        if (!target_warrior || warriorPos.x == -1) {
            current_state = IDLE;
            target_warrior = nullptr;
            break;
        }
        if (!isMoving) {
            SetTarget(warriorPos.x, warriorPos.y, map, securityMap);
            if (!isMoving) {
                current_state = IDLE;
                target_warrior = nullptr;
            }
        }
        else if (isNear(warriorPos)) {
            ApplyEffect(target_warrior); // Give ammo or heal
            current_state = IDLE;
            target_warrior = nullptr;
        }
        break;

    default:
        current_state = IDLE;
        target_warrior = nullptr;
        isMoving = false;
        path.clear();
        break;
    }
}
