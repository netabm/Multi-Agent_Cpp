#pragma once
#include "Soldier.h"
#include "Warrior.h"
#include <vector>

enum SupportState {
    IDLE,
    MOVING_TO_WAREHOUSE,
    MOVING_TO_WARRIOR
};

class SupportSoldier : public Soldier {
protected:
    SupportState current_state = IDLE;
    Warrior* target_warrior = nullptr; // Soldier to supply/heal

    virtual Point2D GetWarehousePosition() const = 0; // Pure virtual: supply/medic warehouse
    virtual void ApplyEffect(Warrior* warrior) = 0;   // Pure virtual: ammo/heal/etc

public:
    SupportSoldier(double start_x, double start_y, int team_id);

    void AssignSupportTask(Warrior* warrior_to_support);

    virtual void Update(int map[MSZ][MSZ], double securityMap[MSZ][MSZ]);
};
