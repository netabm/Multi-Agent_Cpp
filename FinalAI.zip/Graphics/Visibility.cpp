#include "Visibility.h"

// Helper function: Traces a single line of sight
void BresenhamLine(int x1, int y1, int x2, int y2, int map[MSZ][MSZ], bool visible[MSZ][MSZ])
{
    int dx = abs(x2 - x1), dy = abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1, sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;

    while (true) {
        visible[y1][x1] = true; // Mark the current cell as visible

        // If the cell is an obstacle that blocks sight, stop tracing this line
        if (map[y1][x1] == STONE || map[y1][x1] == TREE)
            return;

        if (x1 == x2 && y1 == y2)
            break;

        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x1 += sx; }
        if (e2 < dx) { err += dx; y1 += sy; }
    }
}

// Main function to calculate a soldier's complete field of view
void CalculateVisibility(Soldier* soldier, int map[MSZ][MSZ], bool visible[MSZ][MSZ])
{
    // Reset map
    for (int i = 0; i < MSZ; i++) for (int j = 0; j < MSZ; j++) visible[i][j] = false;

    Point2D pos = soldier->getPosition();

    // Trace lines from the soldier to every cell on the map's perimeter
    for (int i = 0; i < MSZ; i++) {
        BresenhamLine(pos.x, pos.y, i, 0, map, visible);         // Top edge
        BresenhamLine(pos.x, pos.y, i, MSZ - 1, map, visible); // Bottom edge
        BresenhamLine(pos.x, pos.y, 0, i, map, visible);         // Left edge
        BresenhamLine(pos.x, pos.y, MSZ - 1, i, map, visible); // Right edge
    }
}

// Checks if there's a clear line of sight between two points
bool HasLineOfSight(int x1, int y1, int x2, int y2, int map[MSZ][MSZ])
{
    if (x1 < 0 || x1 >= MSZ || y1 < 0 || y1 >= MSZ || x2 < 0 || x2 >= MSZ || y2 < 0 || y2 >= MSZ) {
        return false;
    }
    if (map[y1][x1] == STONE || map[y1][x1] == WATER) {
        return false;
    }


    int dx = abs(x2 - x1), dy = abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1, sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;
    int currentX = x1;
    int currentY = y1;

    while (true) {
        // Stop check just before reaching the target cell
        if (currentX == x2 && currentY == y2) {
            break;
        }

        // Check the *next* potential step based on Bresenham's error term
        int e2 = 2 * err;
        int nextX = currentX;
        int nextY = currentY;

        if (e2 > -dy) {
            err -= dy;
            nextX += sx;
        }
        if (e2 < dx) {
            err += dx;
            nextY += sy;
        }

        // Check if the calculated next step is valid before checking map
        if (nextX < 0 || nextX >= MSZ || nextY < 0 || nextY >= MSZ) {
            return false; // Line went off-map during calculation
        }

        // Check if the intermediate cell (nextX, nextY) blocks LoS
        // If the intermediate cell is the target, don't check it as blocking
        if (!(nextX == x2 && nextY == y2) && (map[nextY][nextX] == STONE || map[nextY][nextX] == TREE)) {
            return false; // Path blocked
        }

        // Move to the next cell
        currentX = nextX;
        currentY = nextY;

        // Failsafe in case of infinite loop
        if (abs(currentX - x1) > MSZ || abs(currentY - y1) > MSZ) {
            return false;
        }
    }
    return true;
}